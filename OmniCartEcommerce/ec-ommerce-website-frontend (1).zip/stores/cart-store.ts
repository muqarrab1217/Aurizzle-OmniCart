"use client"

import { create } from "zustand"
import type { CartLine, Product } from "@/lib/types"

type State = {
  items: CartLine[]
}
type Actions = {
  add: (product: Product, qty?: number) => void
  remove: (id: string) => void
  update: (id: string, qty: number) => void
  clear: () => void
}

export const useCartStore = create<State & Actions>((set) => ({
  items: [],
  add: (product, qty = 1) =>
    set((s) => {
      const exists = s.items.find((i) => i.product.id === product.id)
      if (exists) {
        return {
          items: s.items.map((i) => (i.product.id === product.id ? { ...i, quantity: i.quantity + qty } : i)),
        }
      }
      return { items: [...s.items, { product, quantity: qty }] }
    }),
  remove: (id) => set((s) => ({ items: s.items.filter((i) => i.product.id !== id) })),
  update: (id, qty) =>
    set((s) => ({
      items: s.items
        .map((i) => (i.product.id === id ? { ...i, quantity: Math.max(0, qty) } : i))
        .filter((i) => i.quantity > 0),
    })),
  clear: () => set({ items: [] }),
}))
