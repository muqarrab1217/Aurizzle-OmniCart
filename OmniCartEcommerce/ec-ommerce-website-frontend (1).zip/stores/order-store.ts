"use client"

import { create } from "zustand"
import { addBusinessDays } from "date-fns"
import { nanoid } from "nanoid"
import type { CartLine, Order, TrackingStep } from "@/lib/types"

function makeSteps(createdAt: Date): TrackingStep[] {
  const base = createdAt.getTime()
  const hour = 1000 * 60 * 60
  return [
    { label: "Processing", timestamp: new Date(base + 1 * hour).toISOString() },
    { label: "Packed", timestamp: new Date(base + 8 * hour).toISOString() },
    { label: "Shipped", timestamp: new Date(base + 24 * hour).toISOString() },
    { label: "Out for Delivery", timestamp: new Date(base + 96 * hour).toISOString() },
  ]
}

type State = {
  orders: Order[]
}
type Actions = {
  placeOrder: (lines: CartLine[]) => Order
  getLatestOrderIdForProduct: (productId: string) => string | undefined
}

export const useOrderStore = create<State & Actions>((set, get) => ({
  orders: [],
  placeOrder: (lines) => {
    const created = new Date()
    const items = lines.map((l) => ({
      productId: l.product.id,
      quantity: l.quantity,
      priceAtPurchase: l.product.price,
      shopId: l.product.shopId,
    }))
    const subtotal = lines.reduce((sum, l) => sum + l.product.price * l.quantity, 0)
    const steps = makeSteps(created)
    const order: Order = {
      id: `o-${nanoid(7)}`,
      createdAt: created.toISOString(),
      items,
      subtotal,
      status: "processing",
      steps,
      etaBusinessDays: 5, // 4-5 business days
    }
    set({ orders: [order, ...get().orders] })
    return order
  },
  getLatestOrderIdForProduct: (productId) => {
    const orders = get().orders
    const found = orders.find((o) => o.items.some((it) => it.productId === productId))
    return found?.id
  },
}))

export function getEtaDate(createdAtIso: string, businessDays: number) {
  return addBusinessDays(new Date(createdAtIso), businessDays)
}
