"use client"

import { create } from "zustand"
import { nanoid } from "nanoid"
import { products as initialProducts } from "@/lib/data/products"
import type { Product } from "@/lib/types"

type State = {
  products: Product[]
}
type Actions = {
  createProduct: (p: Omit<Product, "id">) => Product
  updateProduct: (id: string, patch: Partial<Product>) => void
  deleteProduct: (id: string) => void
  reset: () => void
}

export const useProductsStore = create<State & Actions>((set, get) => ({
  products: initialProducts,
  createProduct: (p) => {
    const newP: Product = { ...p, id: `p-${nanoid(6)}` }
    set({ products: [newP, ...get().products] })
    return newP
  },
  updateProduct: (id, patch) =>
    set({
      products: get().products.map((prod) => (prod.id === id ? { ...prod, ...patch, id: prod.id } : prod)),
    }),
  deleteProduct: (id) => set({ products: get().products.filter((p) => p.id !== id) }),
  reset: () => set({ products: initialProducts }),
}))
