"use client"

import { useMemo } from "react"
import { useOrderStore } from "@/stores/order-store"
import { shops } from "@/lib/data/shops"

export default function SuperAdminDashboard() {
  const orders = useOrderStore((s) => s.orders)

  const { totalRevenue, perShop } = useMemo(() => {
    const per: Record<string, number> = {}
    for (const o of orders) {
      for (const it of o.items) {
        per[it.shopId] = (per[it.shopId] || 0) + it.priceAtPurchase * it.quantity
      }
    }
    const total = Object.values(per).reduce((s, v) => s + v, 0)
    return { totalRevenue: total, perShop: per }
  }, [orders])

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Super Admin Overview</h1>
      <div className="mb-6 rounded-lg border p-6">
        <div className="text-sm text-muted-foreground">Total Revenue</div>
        <div className="text-2xl font-semibold">${totalRevenue.toFixed(2)}</div>
      </div>
      <div className="overflow-hidden rounded-xl border">
        <table className="w-full text-left text-sm">
          <thead className="bg-secondary">
            <tr>
              <th className="px-4 py-3">Shop</th>
              <th className="px-4 py-3">Owner</th>
              <th className="px-4 py-3">Revenue</th>
            </tr>
          </thead>
          <tbody>
            {shops.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="px-4 py-3">{s.name}</td>
                <td className="px-4 py-3">{s.ownerName}</td>
                <td className="px-4 py-3">${(perShop[s.id] || 0).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
