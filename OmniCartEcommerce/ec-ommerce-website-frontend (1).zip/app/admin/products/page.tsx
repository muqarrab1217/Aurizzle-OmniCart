"use client"

import { useMemo, useState } from "react"
import { useProductsStore } from "@/stores/products-store"
import { useRoleStore } from "@/stores/role-store"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Product } from "@/lib/types"

const emptyForm: Omit<Product, "id"> = {
  title: "",
  description: "",
  price: 0,
  image: "/placeholder.jpg",
  rating: 0,
  tags: [],
  shopId: "shop-1",
}

export default function ProductsAdminPage() {
  const role = useRoleStore((s) => s.role)
  const managerShop = useRoleStore((s) => s.managerShopId)
  const { products, createProduct, updateProduct, deleteProduct } = useProductsStore()

  const scopedProducts = useMemo(() => {
    return role === "manager" ? products.filter((p) => p.shopId === managerShop) : products
  }, [products, role, managerShop])

  const [form, setForm] = useState<Omit<Product, "id">>({ ...emptyForm, shopId: managerShop || "shop-1" })
  const [editingId, setEditingId] = useState<string | null>(null)

  const canEdit = role === "manager" || role === "super-admin"

  const onSubmit = () => {
    if (!canEdit) return
    if (editingId) {
      updateProduct(editingId, form)
      setEditingId(null)
    } else {
      createProduct(form)
    }
    setForm({ ...emptyForm, shopId: managerShop || "shop-1" })
  }

  const startEdit = (p: Product) => {
    setEditingId(p.id)
    setForm({
      title: p.title,
      description: p.description,
      price: p.price,
      image: p.image,
      rating: p.rating,
      tags: p.tags || [],
      shopId: p.shopId,
    })
  }

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Manage Products</h1>

      {!canEdit ? (
        <div className="rounded-lg border p-6 text-muted-foreground">You need manager or super admin role.</div>
      ) : (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{editingId ? "Update Product" : "Add Product"}</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3">
            <Input
              placeholder="Title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
            <Input
              placeholder="Image URL"
              value={form.image}
              onChange={(e) => setForm({ ...form, image: e.target.value })}
            />
            <Input
              placeholder="Price"
              type="number"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: Number.parseFloat(e.target.value || "0") })}
            />
            <Input
              placeholder="Rating"
              type="number"
              value={form.rating}
              onChange={(e) => setForm({ ...form, rating: Number.parseFloat(e.target.value || "0") })}
            />
            <Input
              placeholder="Tags (comma separated)"
              value={(form.tags || []).join(", ")}
              onChange={(e) =>
                setForm({
                  ...form,
                  tags: e.target.value
                    .split(",")
                    .map((t) => t.trim())
                    .filter(Boolean),
                })
              }
            />
            <Input
              placeholder="Description"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
            {role === "super-admin" && (
              <Input
                placeholder="Shop ID"
                value={form.shopId}
                onChange={(e) => setForm({ ...form, shopId: e.target.value })}
              />
            )}
            <div className="flex gap-2 pt-2">
              <Button onClick={onSubmit}>{editingId ? "Update" : "Add"}</Button>
              {editingId && (
                <Button
                  variant="outline"
                  onClick={() => (setEditingId(null), setForm({ ...emptyForm, shopId: managerShop || "shop-1" }))}
                >
                  Cancel
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="overflow-hidden rounded-xl border">
        <table className="w-full text-left text-sm">
          <thead className="bg-secondary">
            <tr>
              <th className="px-4 py-3">Title</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Shop</th>
              <th className="px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {scopedProducts.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="px-4 py-3">{p.title}</td>
                <td className="px-4 py-3">${p.price.toFixed(2)}</td>
                <td className="px-4 py-3">{p.shopId}</td>
                <td className="px-4 py-3">
                  {canEdit ? (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => startEdit(p)}>
                        Edit
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => deleteProduct(p.id)}>
                        Delete
                      </Button>
                    </div>
                  ) : (
                    <span className="text-muted-foreground">No access</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
