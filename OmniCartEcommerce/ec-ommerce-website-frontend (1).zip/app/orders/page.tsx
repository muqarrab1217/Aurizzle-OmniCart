"use client"

import Link from "next/link"
import { useOrderStore } from "@/stores/order-store"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function OrdersPage() {
  const orders = useOrderStore((s) => s.orders)

  return (
    <section className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Your Orders</h1>
      {orders.length === 0 ? (
        <div className="rounded-lg border p-8 text-center text-muted-foreground">No orders yet.</div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {orders.map((o) => (
            <Card key={o.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Order {o.id}</span>
                  <span className="text-sm font-normal text-muted-foreground">
                    {new Date(o.createdAt).toLocaleString()}
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm">
                <div className="mb-2">Items: {o.items.reduce((s, it) => s + it.quantity, 0)}</div>
                <div className="mb-4">Subtotal: ${o.subtotal.toFixed(2)}</div>
                <Link className="text-primary underline" href={`/orders/${o.id}`}>
                  View tracking
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </section>
  )
}
