"use client"
import { useParams } from "next/navigation"
import { useOrdersStore } from "../../../stores/order-store"

const STEPS: { key: "placed" | "processing" | "shipped" | "out-for-delivery" | "delivered"; label: string }[] = [
  { key: "placed", label: "Order Placed" },
  { key: "processing", label: "Processing" },
  { key: "shipped", label: "Shipped" },
  { key: "out-for-delivery", label: "Out for Delivery" },
  { key: "delivered", label: "Delivered" },
]

export default function OrderTrackingPage() {
  const params = useParams<{ orderId: string }>()
  const order = useOrdersStore((s) => s.getOrder(params.orderId))

  if (!order) {
    return (
      <main className="max-w-3xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-semibold">Tracking</h1>
        <p className="text-muted-foreground mt-2">Order not found.</p>
      </main>
    )
  }

  return (
    <main className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold">Tracking order #{order.id.slice(-6).toUpperCase()}</h1>
      <p className="text-sm text-muted-foreground mt-1">
        Estimated delivery: within {order.etaBusinessDays} business days
      </p>

      <ol className="mt-6 space-y-3">
        {STEPS.map((s) => {
          const visited =
            order.timeline.findIndex((t) => t.status === s.key) <=
            order.timeline.findIndex((t) => t.status === order.status)
          return (
            <li
              key={s.key}
              className={`rounded-xl border p-3 flex items-center justify-between ${visited ? "bg-secondary/50" : ""}`}
            >
              <div className="font-medium">{s.label}</div>
              <div className="text-sm text-muted-foreground">
                {order.timeline.find((t) => t.status === s.key)?.date
                  ? new Date(order.timeline.find((t) => t.status === s.key)!.date).toLocaleString()
                  : "—"}
              </div>
            </li>
          )
        })}
      </ol>
    </main>
  )
}
