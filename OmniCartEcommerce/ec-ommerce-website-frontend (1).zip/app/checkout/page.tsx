"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useCartStore } from "@/stores/cart-store"
import { useOrderStore } from "@/stores/order-store"
import { useRouter } from "next/navigation"

export default function CheckoutPage() {
  const items = useCartStore((s) => s.items)
  const clear = useCartStore((s) => s.clear)
  const place = useOrderStore((s) => s.placeOrder)
  const router = useRouter()

  const onPlace = () => {
    if (items.length === 0) return
    const order = place(items)
    clear()
    router.push(`/orders/${order.id}`)
  }

  return (
    <section className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Checkout</h1>
      <Card>
        <CardHeader>
          <CardTitle>Shipping Details</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input placeholder="First name" />
            <Input placeholder="Last name" />
          </div>
          <Input placeholder="Address" />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input placeholder="City" />
            <Input placeholder="Postal code" />
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Link href="/cart">
              <Button variant="outline">Back to cart</Button>
            </Link>
            <Button onClick={onPlace} className="bg-primary text-primary-foreground hover:bg-primary/90">
              Place order
            </Button>
          </div>
        </CardContent>
      </Card>
    </section>
  )
}
