"use client"

import { notFound, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { useCartStore } from "@/stores/cart-store"
import { useOrderStore } from "@/stores/order-store"
import { useProductsStore } from "@/stores/products-store"

function AddToCart({ id }: { id: string }) {
  const add = useCartStore((s) => s.add)
  const product = useProductsStore((s) => s.products.find((p) => p.id === id))
  if (!product) return null
  return (
    <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => add(product, 1)}>
      Add to cart
    </Button>
  )
}

export default function ProductDetail({ params }: { params: { id: string } }) {
  const router = useRouter()
  const product = useProductsStore((s) => s.products.find((p) => p.id === params.id))
  const latestOrderId = useOrderStore((s) => s.getLatestOrderIdForProduct(params.id))

  if (!product) return notFound()

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <div className="rounded-xl border p-2">
          <img
            src={product.image || "/placeholder.svg?height=800&width=800&query=product image"}
            alt={product.title}
            className="w-full rounded-lg object-cover"
          />
        </div>
        <div className="space-y-4">
          <h1 className="font-serif text-3xl font-bold">{product.title}</h1>
          <p className="text-muted-foreground">{product.description}</p>
          <p className="text-2xl font-semibold">${product.price.toFixed(2)}</p>
          <div className="flex gap-2">
            <AddToCart id={product.id} />
            <Button
              variant="outline"
              onClick={() => (latestOrderId ? router.push(`/orders/${latestOrderId}`) : router.push("/orders"))}
            >
              Track delivery
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
