"use client"

import ProductCard from "@/components/site/product-card"
import { useProductsStore } from "@/stores/products-store"

export default function ShopPage() {
  const products = useProductsStore((s) => s.products)

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Shop</h1>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  )
}
