"use client"
import { useState } from "react"
import { useRoleStore } from "../../../stores/role-store"
import { useProductsStore } from "../../../stores/products-store"
import type { Product } from "../../../lib/types"

export default function ManagerProductsPage() {
  const { shopId } = useRoleStore()
  const { byShop, addProduct, deleteProduct, updateProduct } = useProductsStore()
  const products = byShop(shopId)

  const [draft, setDraft] = useState<Omit<Product, "id">>({
    name: "",
    description: "",
    image: "/modern-tech-product.png",
    price: 0,
    stock: 0,
    shopId,
  })

  const onAdd = () => {
    if (!draft.name) return
    addProduct({ ...draft, shopId })
    setDraft({
      name: "",
      description: "",
      image: "/modern-tech-product.png",
      price: 0,
      stock: 0,
      shopId,
    })
  }

  return (
    <main className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold">Products (Manager)</h1>
      <p className="text-sm text-muted-foreground">Shop-scoped to your selected shop.</p>

      <section className="mt-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            placeholder="Name"
            className="border rounded-md px-3 py-2"
            value={draft.name}
            onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
          />
          <input
            placeholder="Price"
            className="border rounded-md px-3 py-2"
            type="number"
            value={draft.price}
            onChange={(e) => setDraft((d) => ({ ...d, price: Number(e.target.value) }))}
          />
          <input
            placeholder="Stock"
            className="border rounded-md px-3 py-2"
            type="number"
            value={draft.stock}
            onChange={(e) => setDraft((d) => ({ ...d, stock: Number(e.target.value) }))}
          />
          <input
            placeholder="Image URL"
            className="border rounded-md px-3 py-2 col-span-1 md:col-span-2"
            value={draft.image}
            onChange={(e) => setDraft((d) => ({ ...d, image: e.target.value }))}
          />
          <input
            placeholder="Description"
            className="border rounded-md px-3 py-2 col-span-1 md:col-span-2"
            value={draft.description}
            onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
          />
        </div>
        <button
          onClick={onAdd}
          className="mt-3 rounded-xl bg-primary text-primary-foreground px-4 py-2 font-medium shadow-md hover:opacity-90"
        >
          Add Product
        </button>
      </section>

      <section className="mt-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {products.map((p) => (
            <ProductRow
              key={p.id}
              p={p}
              onDelete={() => deleteProduct(p.id)}
              onUpdate={(patch) => updateProduct(p.id, patch)}
            />
          ))}
        </div>
      </section>
    </main>
  )
}

function ProductRow({
  p,
  onDelete,
  onUpdate,
}: {
  p: Product
  onDelete: () => void
  onUpdate: (patch: Partial<Product>) => void
}) {
  const [edit, setEdit] = useState(p)
  return (
    <div className="border rounded-xl p-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <input
          className="border rounded-md px-3 py-2"
          value={edit.name}
          onChange={(e) => setEdit((d) => ({ ...d, name: e.target.value }))}
        />
        <input
          className="border rounded-md px-3 py-2"
          type="number"
          value={edit.price}
          onChange={(e) => setEdit((d) => ({ ...d, price: Number(e.target.value) }))}
        />
        <input
          className="border rounded-md px-3 py-2"
          type="number"
          value={edit.stock}
          onChange={(e) => setEdit((d) => ({ ...d, stock: Number(e.target.value) }))}
        />
        <input
          className="border rounded-md px-3 py-2"
          value={edit.image}
          onChange={(e) => setEdit((d) => ({ ...d, image: e.target.value }))}
        />
        <textarea
          className="border rounded-md px-3 py-2 md:col-span-2"
          value={edit.description}
          onChange={(e) => setEdit((d) => ({ ...d, description: e.target.value }))}
        />
      </div>
      <div className="mt-3 flex items-center gap-2">
        <button className="rounded-lg bg-secondary px-3 py-2 text-sm" onClick={() => onUpdate(edit)}>
          Save
        </button>
        <button className="rounded-lg bg-destructive text-destructive-foreground px-3 py-2 text-sm" onClick={onDelete}>
          Delete
        </button>
      </div>
    </div>
  )
}
