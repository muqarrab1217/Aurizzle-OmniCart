"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { useState } from "react"

export default function SignupPage() {
  const [email, setEmail] = useState("")
  const [pwd, setPwd] = useState("")

  return (
    <section className="mx-auto max-w-md px-4 py-12">
      <h1 className="mb-6 font-serif text-3xl font-bold">Create account</h1>
      <div className="rounded-xl border p-6">
        <div className="grid gap-4">
          <Input placeholder="Name" />
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" type="email" />
          <Input value={pwd} onChange={(e) => setPwd(e.target.value)} placeholder="Password" type="password" />
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">Sign up</Button>
        </div>
        <p className="mt-4 text-sm text-muted-foreground">
          Already have an account?{" "}
          <Link className="text-primary underline" href="/login">
            Log in
          </Link>
        </p>
      </div>
    </section>
  )
}
