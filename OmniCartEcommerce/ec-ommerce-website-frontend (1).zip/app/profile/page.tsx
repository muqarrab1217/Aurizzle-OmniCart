export default function ProfilePage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-4 font-serif text-3xl font-bold">Your Profile</h1>
      <div className="rounded-xl border p-6">
        <p className="text-muted-foreground">
          Profile management coming soon. Connect authentication to enable personalized data.
        </p>
      </div>
    </section>
  )
}
