"use client"

import CartItem from "@/components/cart/cart-item"
import { useCartStore } from "@/stores/cart-store"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function CartPage() {
  const items = useCartStore((s) => s.items)
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0)

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 font-serif text-3xl font-bold">Your Cart</h1>
      {items.length === 0 ? (
        <div className="rounded-lg border p-8 text-center">
          <p className="mb-4 text-muted-foreground">Your cart is empty.</p>
          <Link href="/shop">
            <Button variant="outline">Continue shopping</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="md:col-span-2 space-y-4">
            {items.map((i) => (
              <CartItem key={i.product.id} id={i.product.id} />
            ))}
          </div>
          <aside className="rounded-lg border p-6">
            <h2 className="mb-4 font-serif text-xl font-semibold">Summary</h2>
            <div className="mb-6 flex items-center justify-between">
              <span>Subtotal</span>
              <span className="font-medium">${subtotal.toFixed(2)}</span>
            </div>
            <Link href="/checkout">
              <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">Checkout</Button>
            </Link>
          </aside>
        </div>
      )}
    </section>
  )
}
