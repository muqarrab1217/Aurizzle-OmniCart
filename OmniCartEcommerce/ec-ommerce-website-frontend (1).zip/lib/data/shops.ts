import type { Shop } from "@/lib/types"

export const shops: Shop[] = [
  { id: "shop-1", name: "Audio Hub", ownerName: "Ava Carter" },
  { id: "shop-2", name: "Wearables Co.", ownerName: "Liam Patel" },
  { id: "shop-3", name: "Adventure Cams", ownerName: "Noah Kim" },
]
