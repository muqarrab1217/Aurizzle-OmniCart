export type Product = {
  id: string
  title: string
  description: string
  price: number
  image: string
  rating: number
  tags?: string[]
  shopId: string // which shop owns/sells this product
}

export type CartLine = {
  product: Product
  quantity: number
}

export type Role = "customer" | "manager" | "super-admin"

export type Shop = {
  id: string
  name: string
  ownerName: string
}

export type TrackingStep = {
  label: string
  timestamp: string
}

export type OrderItem = {
  productId: string
  quantity: number
  priceAtPurchase: number
  shopId: string
}

export type Order = {
  id: string
  createdAt: string
  items: OrderItem[]
  subtotal: number
  status: "processing" | "packed" | "shipped" | "out-for-delivery" | "delivered"
  steps: TrackingStep[]
  etaBusinessDays: number
}
