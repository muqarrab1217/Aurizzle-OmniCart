"use client"

import { useCartStore } from "@/stores/cart-store"
import { Minus, Plus, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function CartItem({ id }: { id: string }) {
  const line = useCartStore((s) => s.items.find((i) => i.product.id === id))
  const update = useCartStore((s) => s.update)
  const remove = useCartStore((s) => s.remove)

  if (!line) return null

  return (
    <div className="flex items-center gap-4 rounded-lg border p-4">
      <img
        src={line.product.image || "/placeholder.svg"}
        alt={line.product.title}
        className="h-20 w-20 rounded-md object-cover"
      />
      <div className="flex-1">
        <p className="font-medium">{line.product.title}</p>
        <p className="text-sm text-muted-foreground">${(line.product.price * line.quantity).toFixed(2)}</p>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          aria-label="Decrease quantity"
          onClick={() => update(line.product.id, line.quantity - 1)}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <span className="w-8 text-center">{line.quantity}</span>
        <Button
          variant="outline"
          size="icon"
          aria-label="Increase quantity"
          onClick={() => update(line.product.id, line.quantity + 1)}
        >
          <Plus className="h-4 w-4" />
        </Button>
        <Button variant="destructive" size="icon" aria-label="Remove item" onClick={() => remove(line.product.id)}>
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
