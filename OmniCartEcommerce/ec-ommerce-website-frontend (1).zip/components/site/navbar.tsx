"use client"

import Link from "next/link"
import { ShoppingCart, User, Menu } from "lucide-react"
import { useCartStore } from "@/stores/cart-store"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { useRoleStore } from "@/stores/role-store"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function Navbar() {
  const count = useCartStore((s) => s.items.reduce((sum, i) => sum + i.quantity, 0))
  const [open, setOpen] = useState(false)
  const role = useRoleStore((s) => s.role)
  const setRole = useRoleStore((s) => s.setRole)

  return (
    <header className="border-b bg-card">
      <div className="mx-auto max-w-6xl px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button className="md:hidden" aria-label="Toggle menu" onClick={() => setOpen((v) => !v)}>
              <Menu className="h-6 w-6" />
            </button>
            <Link href="/" className="font-serif text-xl font-semibold tracking-tight">
              OmniCart
            </Link>
          </div>

          <nav className="hidden items-center gap-6 md:flex">
            <Link href="/shop" className="text-sm hover:text-primary">
              Shop
            </Link>
            <Link href="/orders" className="text-sm hover:text-primary">
              Orders
            </Link>
            {(role === "manager" || role === "super-admin") && (
              <Link href="/admin/products" className="text-sm hover:text-primary">
                Products
              </Link>
            )}
            {role === "super-admin" && (
              <Link href="/admin/super" className="text-sm hover:text-primary">
                Super Admin
              </Link>
            )}
          </nav>

          <div className="flex items-center gap-2">
            <Select value={role} onValueChange={(v: any) => setRole(v)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="customer">Customer</SelectItem>
                <SelectItem value="manager">Ecom Manager</SelectItem>
                <SelectItem value="super-admin">Super Admin</SelectItem>
              </SelectContent>
            </Select>

            <Link href="/login" aria-label="Account" className="hidden md:inline-flex">
              <Button variant="ghost" className="gap-2">
                <User className="h-5 w-5" />
                <span className="sr-only">Account</span>
              </Button>
            </Link>
            <Link href="/cart" aria-label="Cart">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5" />
                <span className="sr-only">Cart</span>
                {count > 0 && (
                  <span
                    aria-label={`${count} items in cart`}
                    className="absolute -right-2 -top-2 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-xs font-medium text-accent-foreground"
                  >
                    {count}
                  </span>
                )}
              </Button>
            </Link>
          </div>
        </div>

        {open && (
          <div className="mt-3 flex flex-col gap-2 md:hidden">
            <Link href="/shop" className="py-2 text-sm hover:text-primary" onClick={() => setOpen(false)}>
              Shop
            </Link>
            <Link href="/orders" className="py-2 text-sm hover:text-primary" onClick={() => setOpen(false)}>
              Orders
            </Link>
            {(role === "manager" || role === "super-admin") && (
              <Link href="/admin/products" className="py-2 text-sm hover:text-primary" onClick={() => setOpen(false)}>
                Products
              </Link>
            )}
            {role === "super-admin" && (
              <Link href="/admin/super" className="py-2 text-sm hover:text-primary" onClick={() => setOpen(false)}>
                Super Admin
              </Link>
            )}
            <Link href="/login" className="py-2 text-sm hover:text-primary" onClick={() => setOpen(false)}>
              Login
            </Link>
          </div>
        )}
      </div>
    </header>
  )
}
